<!-- markdownlint-disable MD030 -->

# 流式组件

[English](<./README.md>) | 中文

Flowise的应用集成。包含节点和凭据。

![Flowise](https://github.com/FlowiseAI/Flowise/blob/main/images/flowise.gif?raw=true)

安装：

```bash
npm i flowise-components
```

## 许可证

此存储库中的源代码在[MIT许可证](https://github.com/FlowiseAI/Flowise/blob/master/LICENSE.md)下提供。